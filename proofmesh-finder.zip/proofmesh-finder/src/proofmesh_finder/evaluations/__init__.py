"""Not implemented -- kept for structural parity with a hand-built export's shape.
This host's own correctness proof is ``tests/test_definition_loads.py`` (the
definition loads and compiles on the SDK this host runs on, the same check the
Builder's own test run does) -- there is no separate offline evaluation harness.
Nothing in this export imports this package.
"""
