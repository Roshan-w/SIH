"""Not implemented -- kept for structural parity with a hand-built export's shape.
Any ``knowledge``/RAG tool a node calls goes through the platform's governed
``knowledge`` MCP server (auth, tenant filter, lineage intact) via the SDK's
``MCPClientManager`` -- there is no separate ingestion pipeline populating a local
store. Nothing in this export imports this package.
"""
