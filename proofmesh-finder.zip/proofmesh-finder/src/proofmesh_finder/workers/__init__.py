"""Not implemented -- kept for structural parity with a hand-built export's shape
(see e.g. persona-rag-catalog-export, whose own ``workers/`` is equally an empty
placeholder). This host has no background worker process; everything runs inside
the single FastAPI process started by ``api/main.py``. Add your own worker module
here if you introduce one, and wire it into a separate Dockerfile CMD / Container
App -- nothing in this export currently imports this package.
"""
