"""Agent runtime wiring: registry, the SDK's checkpointed engine, triggers, agent loading.

Every node type the canvas offers runs through ``DefinitionRuntime`` (the same engine the
Builder's test run uses); tools reach the platform MCP servers through it, so auth, tenant
filtering, lineage and the write guard all apply exactly as they do in the Builder.
"""

from __future__ import annotations

import json
import os
from typing import TYPE_CHECKING, Any

from agentzoo.agent.registry import AgentRegistry
from agentzoo.serving.definition_runtime import DefinitionRuntime
from agentzoo.triggers import TriggerHost

from .config import AGENT_NAME, DEFINITIONS_DIR

if TYPE_CHECKING:
    from agentzoo.agent.base import BaseAgent

registry = AgentRegistry()
# Every run is checkpointed and recorded, paused or not (also=...): /invocations, approvals
# (hitl_gate, ask_user), durable waits and the kill switch all come from this runtime.
definition_runtime = DefinitionRuntime(name=AGENT_NAME)


def _served_agents() -> dict[str, BaseAgent]:
    agent = registry.get(AGENT_NAME)
    return {AGENT_NAME: agent} if agent is not None else {}


# Triggers declared by the definition: POST /triggers/{name}; schedulers/pollers run in the lifespan.
triggers = TriggerHost(definition_runtime, service=AGENT_NAME, agents=_served_agents)


def load_agent() -> BaseAgent:
    """Load this host's one agent, or raise: a host serving nothing must not start.

    ``DefinitionRuntime.load`` logs and skips a definition that fails to load (right for a vertical
    host serving many); here that would start a healthy-looking container with no agent.
    """
    loaded = [
        a for a in definition_runtime.load(DEFINITIONS_DIR, also={AGENT_NAME}) if a.manifest.name == AGENT_NAME
    ]
    if not loaded:
        raise RuntimeError(
            f"Agent {AGENT_NAME!r} did not load from {DEFINITIONS_DIR}; see the warning above for the SDK error"
        )
    _refuse_simulating_definition()
    return loaded[0]


def _refuse_simulating_definition() -> None:
    """A definition's own ``metadata.integrity_mode`` outranks AGENTMESH_INTEGRITY_MODE in the SDK, so a
    live host must not start an agent that asks to simulate: it would fake every failed call."""
    declared = definition_runtime.definition(AGENT_NAME).metadata.integrity_mode
    if os.environ.get("AGENTMESH_INTEGRITY_MODE") == "live" and declared and declared != "live":
        raise RuntimeError(
            f"{AGENT_NAME!r} sets integrity_mode: {declared} in its definition, but this host runs live "
            "(AGENTMESH_INTEGRITY_MODE=live). Remove the setting in the Builder and export again, or set "
            f"AGENTMESH_INTEGRITY_MODE={declared} in .env to run it with simulated fallbacks."
        )


def file_fields() -> dict[str, dict[str, Any]]:
    """The agent's file inputs (state fields with ``input.component: file_upload``) and their ``file_config``."""
    out: dict[str, dict[str, Any]] = {}
    for name, spec in (definition_runtime.definition(AGENT_NAME).state or {}).items():
        hint = getattr(spec, "input", None)
        if hint is None or getattr(hint, "component", "") != "file_upload":
            continue
        config = dict(hint.file_config or {})
        accept = config.get("accept") or []
        if isinstance(accept, str):
            accept = accept.split(",")
        config["accept"] = [str(token).strip() for token in accept if str(token).strip()]
        out[name] = {"label": hint.label or name, "file_config": config}
    return out


_INTEGRITY_KEYS = ("verdict", "results", "live", "simulated", "refused", "write_refused")


async def integrity(invocation_id: str | None) -> dict[str, Any] | None:
    """The run's integrity summary, as GET /invocations/{id} reports it."""
    if not invocation_id:
        return None
    row = await definition_runtime.store.get(invocation_id) or {}
    summary = row.get("integrity") or (row.get("latest_state") or {}).get("_integrity")
    if isinstance(summary, str):
        summary = json.loads(summary)
    return {k: summary[k] for k in _INTEGRITY_KEYS if k in summary} if isinstance(summary, dict) else None
