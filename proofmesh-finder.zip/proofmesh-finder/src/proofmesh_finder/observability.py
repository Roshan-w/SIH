"""Phoenix tracing: on only when a collector is configured."""

from __future__ import annotations

import os

from agentzoo.observability.phoenix import setup_phoenix


def maybe_setup_tracing(agent_name: str) -> None:
    """Trace only when a collector is configured.

    The SDK's own default collector is an in-environment host, which a laptop cannot reach —
    tracing on by default would mean every export fails and retries in the background forever.
    """
    if os.environ.get("PHOENIX_COLLECTOR_ENDPOINT"):
        setup_phoenix(f"agentmesh-{agent_name}")
