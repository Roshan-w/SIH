"""Request/response bodies for POST /invoke and POST /intake."""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel


class InvokeRequest(BaseModel):
    """Request body for agent invocation."""

    input: dict[str, Any]
    config: dict[str, Any] | None = None


class InvokeResponse(BaseModel):
    """Response body for agent invocation."""

    agent_name: str
    status: str
    output: dict[str, Any]
    error: str | None = None
    #: The run's integrity summary: verdict (all_live / contains_simulated), live and simulated result
    #: counts, and write_refused (writes the backend refused). The full record: GET /invocations/{id}.
    integrity: dict[str, Any] | None = None
    #: Files the run produced (write_document): name, size, content_type, path, and download (GET /files/...).
    files_produced: list[dict[str, Any]] = []


class IntakeResponse(InvokeResponse):
    """POST /intake: the run, plus the platform's reference for each stored file."""

    files: list[dict[str, Any]]
