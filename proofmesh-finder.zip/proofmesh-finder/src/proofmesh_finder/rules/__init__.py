"""Not implemented -- kept for structural parity with a hand-built export's shape.
This host's own prompts and guardrails live in ``definitions/<name>.yaml`` (the
``prompts:``/``guardrails:`` blocks), interpreted by the SDK at runtime -- there
is no separate declarative rules layer. Nothing in this export imports this
package.
"""
