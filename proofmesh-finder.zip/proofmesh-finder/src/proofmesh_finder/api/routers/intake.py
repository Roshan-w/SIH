"""POST /intake/{agent_name}: run the agent on uploaded files. GET /intake: a small upload page.

Nothing is parsed here. Each file is stored on the platform by the data gateway's store_file tool
(MCP_DATA_GATEWAY_URL, on the VPN, like every other tool call) and the agent gets the file reference in
its file field, then reads the file on the platform with the data gateway's read_document tool. File
bytes never enter run state or the invocation store.
"""

from __future__ import annotations

import base64
import json
from typing import Annotated, Any

from fastapi import APIRouter, File, Form, HTTPException, UploadFile
from fastapi.responses import HTMLResponse

from agentzoo.mcp.client import MCPClientManager

from ...config import AGENT_NAME, BASE_NAME
from ...runtime import file_fields
from ...schemas import IntakeResponse
from .invoke import resolve_agent, run_agent

router = APIRouter()

_MB = 1024 * 1024


def _field(name: str) -> tuple[str, dict[str, Any]]:
    fields = file_fields()
    if not fields:
        raise HTTPException(
            status_code=400,
            detail=f"{AGENT_NAME} has no file input (a state field with input.component: file_upload): "
            "add one in the Builder and export again",
        )
    if name:
        if name not in fields:
            raise HTTPException(status_code=400, detail=f"no file field {name!r}; the file fields are {sorted(fields)}")
        return name, fields[name]
    if len(fields) > 1:
        raise HTTPException(status_code=400, detail=f"say which file field to fill with 'field': {sorted(fields)}")
    return next(iter(fields.items()))


def _accepted(filename: str, content_type: str, accept: list[str]) -> bool:
    """``accept`` as in the Builder's file_config: extensions (.pdf), MIME types, or type/* wildcards."""
    if not accept:
        return True
    name, ctype = filename.lower(), (content_type or "").lower()
    for token in (t.lower() for t in accept):
        if (token.startswith(".") and name.endswith(token)) or token == ctype:
            return True
        if token.endswith("/*") and ctype.startswith(token[:-1]):
            return True
    return False


async def _store(upload: UploadFile, limit: int) -> dict[str, Any]:
    """Store one file on the platform (the data gateway's store_file): its reference, never a simulated one."""
    data = await upload.read(limit + 1)
    if len(data) > limit:
        raise HTTPException(status_code=413, detail=f"{upload.filename} is larger than {limit / _MB:g} MB")
    name = upload.filename or "file"
    try:
        out = await MCPClientManager().data_gateway.call_tool(
            "store_file",
            {
                "content": base64.b64encode(data).decode("ascii"),
                "name": name,
                "content_type": upload.content_type or "application/octet-stream",
                "agent": AGENT_NAME,
                "requested_by": AGENT_NAME,
            },
            compress=False,
        )
    except Exception as exc:
        raise HTTPException(
            status_code=502,
            detail=f"the data gateway did not store {name} ({type(exc).__name__}: {exc}): is the VPN up, "
            "and is MCP_DATA_GATEWAY_URL in .env right?",
        ) from exc
    ref = out.get("file") if isinstance(out, dict) else None
    if not isinstance(ref, dict) or out.get("status") != "stored" or ref.get("simulated"):
        code = int(out.get("status_code") or 502) if isinstance(out, dict) else 502
        reason = (out.get("error") or out.get("refusal") or out) if isinstance(out, dict) else out
        raise HTTPException(
            status_code=code if 400 <= code < 500 else 502, detail=f"the platform did not store {name}: {reason}"
        )
    return ref


@router.post("/intake/{agent_name}", response_model=IntakeResponse)
async def intake(
    agent_name: str,
    file: Annotated[list[UploadFile], File(description="One file, or several when the field takes several")],
    field: Annotated[str, Form(description="The file field to fill (needed only when it has several)")] = "",
    inputs: Annotated[str, Form(alias="input", description="The agent's other inputs, as a JSON object")] = "",
) -> IntakeResponse:
    """Store the file(s) on the platform, put the reference(s) in the agent's file field and run the agent."""
    resolve_agent(agent_name)
    name, spec = _field(field)
    config = spec.get("file_config") or {}
    many = bool(config.get("multiple"))
    max_files = int(config.get("max_files") or (20 if many else 1))
    if len(file) > max_files:
        raise HTTPException(status_code=400, detail=f"{name!r} takes at most {max_files} file(s)")
    limit = int(float(config.get("max_size_mb") or 25) * _MB)
    for upload in file:
        accept = list(config.get("accept") or [])
        if not _accepted(upload.filename or "", upload.content_type or "", accept):
            raise HTTPException(status_code=415, detail=f"{upload.filename}: {name!r} accepts {', '.join(accept)}")
    try:
        payload = json.loads(inputs) if inputs.strip() else {}
    except json.JSONDecodeError as exc:
        raise HTTPException(status_code=400, detail=f"input is not JSON: {exc}") from exc
    if not isinstance(payload, dict):
        raise HTTPException(status_code=400, detail="input must be a JSON object")
    refs = [await _store(upload, limit) for upload in file]
    payload[name] = refs if many else refs[0]
    result = await run_agent(agent_name, payload)
    return IntakeResponse(**result.model_dump(), files=refs)


@router.get("/intake", response_class=HTMLResponse, include_in_schema=False)
async def intake_page() -> HTMLResponse:
    """A minimal page to pick a file and run the agent on it (POSTs to /intake/<agent>)."""
    try:
        fields = file_fields()
    except KeyError:
        fields = {}
    data = {"agent": BASE_NAME, "fields": fields}
    return HTMLResponse(_PAGE.replace("__DATA__", json.dumps(data).replace("<", "\\u003c")))


_PAGE = """<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Intake</title>
<style>
body{font-family:system-ui,sans-serif;max-width:760px;margin:2rem auto;padding:0 16px;color:#1f2328}
label{display:block;margin:.9rem 0 .3rem;font-weight:600} select,input[type=file],textarea{width:100%}
textarea{min-height:5rem;font-family:ui-monospace,monospace} button{margin-top:1rem;padding:.5rem 1.2rem}
pre{background:#f6f8fa;padding:1rem;overflow:auto;white-space:pre-wrap}
</style></head>
<body>
<h1>Run <span id="agent"></span> on a file</h1>
<p>The file is stored on the platform and read there (VPN required). Nothing is parsed on this machine.</p>
<form id="form">
<label for="field">File input</label><select id="field"></select>
<label for="file">File</label><input id="file" type="file" required>
<label for="input">Other inputs (JSON, optional)</label><textarea id="input" placeholder='{"question": "..."}'></textarea>
<button type="submit">Run</button>
</form>
<ul id="files"></ul>
<pre id="out"></pre>
<script>
const DATA = __DATA__;
const out = document.getElementById("out"), sel = document.getElementById("field"), file = document.getElementById("file");
document.getElementById("agent").textContent = DATA.agent;
for (const [name, f] of Object.entries(DATA.fields)) {
  const o = document.createElement("option"); o.value = name; o.textContent = f.label + " (" + name + ")"; sel.appendChild(o);
}
if (!sel.options.length) out.textContent = "This agent has no file input: add a file_upload field in the Builder and export again.";
function sync() { const c = (DATA.fields[sel.value] || {}).file_config || {}; file.accept = (c.accept || []).join(","); file.multiple = !!c.multiple; }
sel.addEventListener("change", sync); sync();
document.getElementById("form").addEventListener("submit", async (e) => {
  e.preventDefault(); out.textContent = "Uploading and running...";
  const body = new FormData();
  for (const f of file.files) body.append("file", f);
  body.append("field", sel.value); body.append("input", document.getElementById("input").value);
  try {
    const r = await fetch("intake/" + encodeURIComponent(DATA.agent), {method: "POST", body});
    const res = await r.json();
    out.textContent = JSON.stringify(res, null, 2);
    const list = document.getElementById("files"); list.textContent = "";
    for (const f of res.files_produced || []) {
      const li = document.createElement("li"), a = document.createElement("a");
      a.href = f.download.replace(/^\\//, ""); a.textContent = "Download " + f.name; a.download = f.name;
      li.appendChild(a); list.appendChild(li);
    }
  } catch (err) { out.textContent = String(err); }
});
</script>
</body></html>
"""
