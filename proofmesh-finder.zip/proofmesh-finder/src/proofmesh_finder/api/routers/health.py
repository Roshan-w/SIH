"""GET /health -- liveness plus build provenance."""

from __future__ import annotations

from typing import Any

from fastapi import APIRouter

from ...config import AGENT_NAME, BUILD
from ...runtime import registry

router = APIRouter()


@router.get("/health")
async def health_check() -> dict[str, Any]:
    """Liveness plus build provenance (unauthenticated: a commit SHA is not a secret)."""
    return {
        "status": "healthy",
        "service": AGENT_NAME,
        "agents": registry.list_agent_names(),
        "build": BUILD,
    }
