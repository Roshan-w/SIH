"""POST /invoke/{agent_name} -- run the agent."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from fastapi import APIRouter, HTTPException

from agentzoo.serving.definition_runtime import PENDING_HITL

from ...config import AGENT_NAME, BASE_NAME
from ...runtime import integrity, registry
from ...schemas import InvokeRequest, InvokeResponse
from .files import remember

if TYPE_CHECKING:
    from agentzoo.agent.base import BaseAgent

router = APIRouter()


def resolve_agent(agent_name: str) -> tuple[str, BaseAgent]:
    """The served agent under ``agent_name`` (its Builder name works too), or 404."""
    agent_name = AGENT_NAME if agent_name == BASE_NAME else agent_name
    agent = registry.get(agent_name)
    if agent is None:
        raise HTTPException(status_code=404, detail=f"Agent '{agent_name}' not found")
    return agent_name, agent


@router.post("/invoke/{agent_name}", response_model=InvokeResponse)
async def invoke_agent(agent_name: str, request: InvokeRequest) -> InvokeResponse:
    """Invoke the agent. ``status`` is ``pending_hitl`` when the run paused for a decision."""
    return await run_agent(agent_name, request.input)


async def run_agent(agent_name: str, payload: dict[str, Any]) -> InvokeResponse:
    """Run the agent on ``payload`` (shared by /invoke and /intake)."""
    agent_name, agent = resolve_agent(agent_name)
    try:
        result = await agent.invoke(payload)
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc
    status = "success" if result.success else "error"
    if result.success and result.data.get("invocation_status") == PENDING_HITL:
        status = PENDING_HITL  # decide via POST /approvals/{invocation_id}
    return InvokeResponse(
        agent_name=agent_name,
        status=status,
        output=result.data,
        error=result.error,
        integrity=await integrity(result.data.get("invocation_id")),
        files_produced=remember(result.data),
    )
