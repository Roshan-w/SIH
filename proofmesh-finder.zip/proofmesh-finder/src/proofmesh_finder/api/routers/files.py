"""GET /files/{path}: download a file this host's runs produced (the data gateway's write_document, AB#1809).

Only files that a run of this host produced since it started are served: their references (FileRefs under
outputs/ in the platform's upload container) are remembered from each run's output, and the bytes are fetched
on request with the data gateway's read_blob tool (MCP_DATA_GATEWAY_URL, on the VPN). People's uploads and any
other blob are not served here.
"""

from __future__ import annotations

import base64
import re
from typing import Any

from fastapi import APIRouter, HTTPException
from fastapi.responses import Response

from agentzoo.mcp.client import MCPClientManager

router = APIRouter()

_OUTPUT_PATH = re.compile(r"^outputs/[A-Za-z0-9_-]{1,64}/\d{4}/\d{2}/\d{2}/[0-9a-f]{32}/[A-Za-z0-9._-]{1,120}$")
_MAX_REMEMBERED = 500
#: path -> FileRef of every file a run of this host produced (oldest dropped past _MAX_REMEMBERED).
PRODUCED: dict[str, dict[str, Any]] = {}


def remember(output: Any) -> list[dict[str, Any]]:
    """Remember the files a run produced (FileRefs under outputs/ anywhere in its output); describe each with
    the local URL that downloads it."""
    found: dict[str, dict[str, Any]] = {}

    def walk(value: Any, depth: int) -> None:
        if depth > 12 or len(found) >= 50:
            return
        if isinstance(value, dict):
            path = value.get("path")
            if (value.get("kind") == "file" and not value.get("simulated") and isinstance(path, str)
                    and _OUTPUT_PATH.match(path)):
                found.setdefault(path, value)
            for child in value.values():
                walk(child, depth + 1)
        elif isinstance(value, list):
            for child in value:
                walk(child, depth + 1)

    walk(output, 0)
    described = []
    for path, ref in found.items():
        if path not in PRODUCED and len(PRODUCED) >= _MAX_REMEMBERED:
            PRODUCED.pop(next(iter(PRODUCED)))
        PRODUCED[path] = ref
        described.append({
            "name": ref.get("name") or path.rsplit("/", 1)[-1],
            "size": ref.get("size") or 0,
            "content_type": ref.get("content_type") or "",
            "path": path,
            "download": f"/files/{path}",
        })
    return described


@router.get("/files/{path:path}")
async def download_file(path: str) -> Response:
    """The bytes of a file a run of this host produced, as an attachment (fetched from the platform)."""
    ref = PRODUCED.get(path)
    if ref is None:
        raise HTTPException(
            status_code=404, detail="not a file this host produced (only files from runs since it started are served)"
        )
    name = path.rsplit("/", 1)[-1]
    try:
        out = await MCPClientManager().data_gateway.call_tool("read_blob", {"file": ref, "as_text": False})
    except Exception as exc:
        raise HTTPException(
            status_code=502,
            detail=f"the data gateway did not return {name} ({type(exc).__name__}: {exc}): is the VPN up?",
        ) from exc
    if not isinstance(out, dict) or out.get("status") != "ok" or not out.get("base64"):
        reason = (out.get("error") or out.get("status")) if isinstance(out, dict) else out
        raise HTTPException(status_code=502, detail=f"the platform did not return {name}: {reason}")
    return Response(
        content=base64.b64decode(out["base64"]),
        media_type=out.get("content_type") or ref.get("content_type") or "application/octet-stream",
        headers={"Content-Disposition": f'attachment; filename="{name}"', "X-Content-Type-Options": "nosniff"},
    )
