"""Compatibility entrypoint.

The real host lives in ``api/main.py`` (app, lifespan, routers), ``runtime.py`` (SDK engine,
agent loading), ``config.py`` (env, naming, build provenance), ``observability.py`` and
``schemas.py``. This module just re-exports what the Dockerfile's ``CMD``, the pyproject
script (``proofmesh_checker.app:main``), the start scripts and the generated test expect to find at
``proofmesh_checker.app`` unchanged.
"""

from __future__ import annotations

from .api.main import app, main
from .config import AGENT_NAME, BASE_NAME, DEFINITIONS_DIR
from .runtime import load_agent

__all__ = ["AGENT_NAME", "BASE_NAME", "DEFINITIONS_DIR", "app", "load_agent", "main"]

if __name__ == "__main__":
    main()
