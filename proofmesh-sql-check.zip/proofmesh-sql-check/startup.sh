#!/usr/bin/env bash
# Proofmesh Sql Check: set up and start the agent host locally (macOS, Linux, WSL).
#   ./startup.sh           first run: venv + packages + spaCy model; then start on $PORT from .env
#   ./startup.sh --docker  build the container image and run it with .env instead
# Needs Python 3.11+, the VPN, and read access to the AgentMesh package feed: your `az login`, a
# personal access token (Packaging: Read) in AZURE_DEVOPS_PAT, or the service principal in .env.
set -euo pipefail
cd "$(dirname "$0")"

SDK_FEED="https://pkgs.dev.azure.com/Zenlabs-Agent-Foundry/Zenlabs-Agent-Foundry/_packaging/agentzoo-sdk/pypi/simple/"
HORIZONTAL_FEED=""

if [ ! -f .env ]; then
  cp .env.example .env
  echo "Created .env from .env.example (the platform endpoints are filled in): review it."
fi

# .env holds plain KEY=value lines. A variable already set (non-empty) in your shell wins, as in the app.
while IFS= read -r line || [ -n "$line" ]; do
  line="${line%$'\r'}"
  case "$line" in '' | '#'*) continue ;; esac
  key="${line%%=*}"
  [[ "$key" =~ ^[A-Za-z_][A-Za-z0-9_]*$ ]] || continue
  [ -n "${!key:-}" ] || export "$key=${line#*=}"
done < .env

missing=""
for k in MCP_DATA_GATEWAY_URL MCP_LLM_ROUTER_URL MCP_KNOWLEDGE_URL; do [ -n "${!k:-}" ] || missing="$missing $k"; done
[ -z "$missing" ] || { echo "Fill in .env first:$missing" >&2; exit 1; }

# An Azure DevOps token for the service principal in .env (the secret reaches Python through the
# environment, never a command line).
sp_token() {
  local pyc
  pyc=$(command -v python3 || command -v python) || { echo "Signing in the service principal needs Python 3" >&2; return 1; }
  "$pyc" - << 'PY'
import json, os, sys, urllib.error, urllib.parse, urllib.request

missing = [k for k in ("AZURE_TENANT_ID", "AZURE_CLIENT_ID", "AZURE_CLIENT_SECRET") if not os.environ.get(k)]
if missing:
    sys.exit("The service principal needs AZURE_TENANT_ID, AZURE_CLIENT_ID and AZURE_CLIENT_SECRET in .env; missing: " + ", ".join(missing))
authority = (os.environ.get("AZURE_AUTHORITY_HOST") or "login.microsoftonline.com").rstrip("/")
if "://" not in authority:
    authority = "https://" + authority
body = urllib.parse.urlencode({
    "grant_type": "client_credentials",
    "client_id": os.environ["AZURE_CLIENT_ID"],
    "client_secret": os.environ["AZURE_CLIENT_SECRET"],
    "scope": "499b84ac-1321-427f-aa17-267ca6975798/.default",
}).encode()
url = f"{authority}/{urllib.parse.quote(os.environ['AZURE_TENANT_ID'], safe='')}/oauth2/v2.0/token"
try:
    with urllib.request.urlopen(urllib.request.Request(url, data=body), timeout=30) as resp:
        print(json.load(resp)["access_token"])
except urllib.error.HTTPError as exc:
    try:
        detail = str(json.load(exc).get("error_description") or "").splitlines()[0]
    except Exception:  # noqa: BLE001 - the status is reported either way
        detail = ""
    sys.exit(f"Service principal sign-in failed (HTTP {exc.code}): {detail or 'no detail'}. Check AZURE_TENANT_ID, AZURE_CLIENT_ID and AZURE_CLIENT_SECRET in .env.")
except Exception as exc:  # noqa: BLE001 - reported
    sys.exit(f"Could not reach the Entra sign-in endpoint ({authority}): {exc}")

PY
}

# A feed URL with credentials (never printed): $AZURE_DEVOPS_PAT, else the service principal in .env
# (AZURE_CLIENT_SECRET set), else an Azure DevOps token from az.
feed_url() {
  local token="${AZURE_DEVOPS_PAT:-}"
  if [ -z "$token" ] && [ -n "${AZURE_CLIENT_SECRET:-}" ]; then
    token=$(sp_token) || return 1
  fi
  if [ -z "$token" ]; then
    command -v az > /dev/null || { echo "The package feed needs az (az login), AZURE_DEVOPS_PAT, or a service principal in .env" >&2; return 1; }
    token=$(az account get-access-token --resource 499b84ac-1321-427f-aa17-267ca6975798 --query accessToken -o tsv) \
      || { echo "Run az login first (or set AZURE_DEVOPS_PAT, or a service principal in .env)" >&2; return 1; }
  fi
  echo "https://build:${token}@${1#https://}"
}

port="${PORT:-8000}"

if [ "${1:-}" = "--docker" ]; then
  engine=$(command -v docker || command -v podman) || { echo "Need Docker or Podman" >&2; exit 1; }
  sdk_url=$(feed_url "$SDK_FEED")
  build_args=(--build-arg "ARTIFACTS_FEED_URL=$sdk_url")
  if [ -n "$HORIZONTAL_FEED" ]; then
    horizontal_url=$(feed_url "$HORIZONTAL_FEED")
    build_args+=(--build-arg "HORIZONTAL_FEED_URL=$horizontal_url")
  fi
  if PYC=$(command -v python3 || command -v python); then
    FEED_CHECK_SDK="$sdk_url" FEED_CHECK_HORIZONTAL="${horizontal_url:-}" "$PYC" - << 'PY'
import base64, os, sys, urllib.error, urllib.parse, urllib.request

for name in ("SDK", "HORIZONTAL"):
    feed = os.environ.get(f"FEED_CHECK_{name}", "")
    if not feed:
        continue
    u = urllib.parse.urlsplit(feed)
    plain = urllib.parse.urlunsplit((u.scheme, u.hostname + (f":{u.port}" if u.port else ""), u.path, "", ""))
    package = "agentzoo-sdk" if name == "SDK" else "agentzoo-agent-horizontal"
    auth = base64.b64encode(f"build:{urllib.parse.unquote(u.password or '')}".encode()).decode()
    req = urllib.request.Request(plain.rstrip("/") + f"/{package}/", headers={"Authorization": f"Basic {auth}"})
    try:
        urllib.request.urlopen(req, timeout=30).close()
    except urllib.error.HTTPError as exc:
        if exc.code in (401, 403):
            sys.exit(
                f"No read access to the AgentMesh package feed for {package} (HTTP {exc.code}).\n"
                "  Your own account: Ask to be added to the AgentMesh developers group in Azure DevOps (Zenlabs-Agent-Foundry): it gives read access to the package feeds, then run az login again.\n"
                "  A personal access token (AZURE_DEVOPS_PAT): it needs the Packaging: Read scope.\n"
                "  The service principal in .env: it must be a member of the Azure DevOps organisation, with Reader on the feed."
            )
        sys.exit(f"The AgentMesh package feed answered HTTP {exc.code} for {package} ({plain})")
    except Exception as exc:  # noqa: BLE001 - reported
        sys.exit(f"Could not reach the AgentMesh package feed ({plain}): {exc}. Check your internet connection.")
print("Package feed access: ok")

PY
  fi
  "$engine" build "${build_args[@]}" -t ca-agent-proofmesh-sql-check:local .
  echo "Starting on http://localhost:$port (run state kept in volume ca-agent-proofmesh-sql-check-state)"
  exec "$engine" run --rm --env-file .env -e "PORT=$port" -p "$port:$port" -v ca-agent-proofmesh-sql-check-state:/app/.local ca-agent-proofmesh-sql-check:local
fi

PY=""
for c in python3.13 python3.12 python3.11 python3 python; do
  if command -v "$c" > /dev/null && "$c" -c 'import sys; sys.exit(sys.version_info < (3, 11))' 2> /dev/null; then
    PY="$c"
    break
  fi
done
[ -n "$PY" ] || { echo "Need Python 3.11 or later" >&2; exit 1; }
[ -d .venv ] || "$PY" -m venv .venv
VPY=.venv/bin/python

want=$(cksum < pyproject.toml)
if [ "$(cat .venv/.installed 2> /dev/null)" != "$want" ]; then
  echo "Installing packages from the AgentMesh feed..."
  sdk_url="${ARTIFACTS_FEED_URL:-}"
  [ -n "$sdk_url" ] || sdk_url=$(feed_url "$SDK_FEED")
  index=(--extra-index-url "$sdk_url")
  if [ -n "$HORIZONTAL_FEED" ]; then
    horizontal_url="${HORIZONTAL_FEED_URL:-}"
    [ -n "$horizontal_url" ] || horizontal_url=$(feed_url "$HORIZONTAL_FEED")
    index+=(--extra-index-url "$horizontal_url")
  fi
  FEED_CHECK_SDK="$sdk_url" FEED_CHECK_HORIZONTAL="${horizontal_url:-}" "$VPY" - << 'PY'
import base64, os, sys, urllib.error, urllib.parse, urllib.request

for name in ("SDK", "HORIZONTAL"):
    feed = os.environ.get(f"FEED_CHECK_{name}", "")
    if not feed:
        continue
    u = urllib.parse.urlsplit(feed)
    plain = urllib.parse.urlunsplit((u.scheme, u.hostname + (f":{u.port}" if u.port else ""), u.path, "", ""))
    package = "agentzoo-sdk" if name == "SDK" else "agentzoo-agent-horizontal"
    auth = base64.b64encode(f"build:{urllib.parse.unquote(u.password or '')}".encode()).decode()
    req = urllib.request.Request(plain.rstrip("/") + f"/{package}/", headers={"Authorization": f"Basic {auth}"})
    try:
        urllib.request.urlopen(req, timeout=30).close()
    except urllib.error.HTTPError as exc:
        if exc.code in (401, 403):
            sys.exit(
                f"No read access to the AgentMesh package feed for {package} (HTTP {exc.code}).\n"
                "  Your own account: Ask to be added to the AgentMesh developers group in Azure DevOps (Zenlabs-Agent-Foundry): it gives read access to the package feeds, then run az login again.\n"
                "  A personal access token (AZURE_DEVOPS_PAT): it needs the Packaging: Read scope.\n"
                "  The service principal in .env: it must be a member of the Azure DevOps organisation, with Reader on the feed."
            )
        sys.exit(f"The AgentMesh package feed answered HTTP {exc.code} for {package} ({plain})")
    except Exception as exc:  # noqa: BLE001 - reported
        sys.exit(f"Could not reach the AgentMesh package feed ({plain}): {exc}. Check your internet connection.")
print("Package feed access: ok")

PY
  "$VPY" -m pip install -q --upgrade pip
  "$VPY" -m pip install -q "${index[@]}" -e ".[dev]"
  echo "$want" > .venv/.installed
fi

# Governance (PII) needs spaCy's en_core_web_lg; without it the first run downloads it mid-request.
# SPACY_MODEL_WHEEL: a local or mirrored copy of the model wheel, instead of downloading it.
if ! "$VPY" -c "import en_core_web_lg" 2> /dev/null; then
  echo "Installing the spaCy model en_core_web_lg (about 400 MB, once)..."
  if [ -n "${SPACY_MODEL_WHEEL:-}" ]; then "$VPY" -m pip install -q "$SPACY_MODEL_WHEEL"; else "$VPY" -m spacy download en_core_web_lg; fi
fi

"$VPY" - << 'PY'
import concurrent.futures, os, sys, urllib.request

keys = sorted(k for k, v in os.environ.items() if k.startswith("MCP_") and k.endswith("_URL") and v)
print("Checking the platform endpoints (a first call can take a minute: they scale to zero)...")

def probe(key):
    try:
        with urllib.request.urlopen(os.environ[key].rstrip("/") + "/health", timeout=90):
            return key, ""
    except Exception as exc:  # noqa: BLE001 - reported below
        return key, str(exc)[:160]

bad = []
with concurrent.futures.ThreadPoolExecutor(8) as pool:
    for key, error in pool.map(probe, keys):
        print(f"  {key}: {'ok' if not error else 'NOT REACHABLE: ' + error}")
        if error:
            bad.append(key)
if bad:
    sys.exit("Not reachable: " + ", ".join(bad) + ". Is the VPN up, and are the URLs in .env right?")
PY

if [ -z "${AZURE_CLIENT_SECRET:-}" ] && ! az account show > /dev/null 2>&1; then
  echo "Note: no Azure identity (az login, or a service principal in .env). Content safety checks will fail, and strict agents refuse to run."
fi

if [ -n "${AZURE_TENANT_ID:-}" ] && [ "${AUTH_MODE:-}" != "dev" ]; then
  echo "Note: AZURE_TENANT_ID is set but AUTH_MODE is not dev: MCP calls will carry Entra tokens, which the platform's MCP servers refuse unless that identity is registered with them, and /invoke will want a token. Set AUTH_MODE=dev in .env."
fi

if [ -z "${AGENT_NAME_PREFIX:-}" ]; then
  echo "Note: AGENT_NAME_PREFIX is empty: everyone running proofmesh-sql-check unprefixed shares its budgets and audit. Set your team id in .env."
fi
echo "Starting on http://localhost:$port  (POST /invoke/proofmesh-sql-check, GET /intake, GET /health)"
exec "$VPY" -m proofmesh_sql_check.app
