# Proofmesh Sql Check: set up and start the agent host locally (Windows PowerShell 5.1+ or PowerShell 7).
#   .\startup.ps1          first run: venv + packages + spaCy model; then start on $PORT from .env
#   .\startup.ps1 -Docker  build the container image and run it with .env instead
# If scripts are blocked: powershell -ExecutionPolicy Bypass -File .\startup.ps1
# Needs Python 3.11+, the VPN, and read access to the AgentMesh package feed: your `az login`, a
# personal access token (Packaging: Read) in AZURE_DEVOPS_PAT, or the service principal in .env.
param([switch]$Docker)
# Continue, not Stop: Windows PowerShell 5.1 turns a native command's redirected stderr into a
# terminating error. Every native call checks $LASTEXITCODE instead; throw still stops the script.
$ErrorActionPreference = 'Continue'
Set-Location -Path $PSScriptRoot

$SdkFeed = 'https://pkgs.dev.azure.com/Zenlabs-Agent-Foundry/Zenlabs-Agent-Foundry/_packaging/agentzoo-sdk/pypi/simple/'
$HorizontalFeed = ''

if (-not (Test-Path .env)) {
    Copy-Item .env.example .env
    Write-Host 'Created .env from .env.example (the platform endpoints are filled in): review it.'
}

# .env holds plain KEY=value lines. A variable already set (non-empty) in your session wins, as in the app.
foreach ($raw in Get-Content .env) {
    $line = $raw.Trim()
    if ($line -eq '' -or $line.StartsWith('#')) { continue }
    $i = $line.IndexOf('=')
    if ($i -lt 1) { continue }
    $key = $line.Substring(0, $i)
    if ($key -notmatch '^[A-Za-z_][A-Za-z0-9_]*$') { continue }
    if (-not [Environment]::GetEnvironmentVariable($key)) {
        [Environment]::SetEnvironmentVariable($key, $line.Substring($i + 1))
    }
}

$missing = @('MCP_DATA_GATEWAY_URL', 'MCP_LLM_ROUTER_URL', 'MCP_KNOWLEDGE_URL') |
    Where-Object { -not [Environment]::GetEnvironmentVariable($_) }
if ($missing) { throw "Fill in .env first: $($missing -join ', ')" }

# An Azure DevOps token for the service principal in .env (client credentials; the secret stays in memory).
function Get-SpToken {
    $missing = @('AZURE_TENANT_ID', 'AZURE_CLIENT_ID', 'AZURE_CLIENT_SECRET') |
        Where-Object { -not [Environment]::GetEnvironmentVariable($_) }
    if ($missing) { throw "The service principal needs AZURE_TENANT_ID, AZURE_CLIENT_ID and AZURE_CLIENT_SECRET in .env; missing: $($missing -join ', ')" }
    # Windows PowerShell 5.1 may not offer TLS 1.2 by default; the sign-in endpoint requires it.
    [Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12
    $authority = if ($env:AZURE_AUTHORITY_HOST) { $env:AZURE_AUTHORITY_HOST.TrimEnd('/') } else { 'login.microsoftonline.com' }
    if ($authority -notmatch '://') { $authority = 'https://' + $authority }
    $body = @{
        grant_type    = 'client_credentials'
        client_id     = $env:AZURE_CLIENT_ID
        client_secret = $env:AZURE_CLIENT_SECRET
        scope         = '499b84ac-1321-427f-aa17-267ca6975798/.default'
    }
    try {
        $resp = Invoke-RestMethod -Method Post -Uri ($authority + '/' + [Uri]::EscapeDataString($env:AZURE_TENANT_ID) + '/oauth2/v2.0/token') `
            -Body $body -ContentType 'application/x-www-form-urlencoded' -ErrorAction Stop
    } catch {
        throw "Service principal sign-in failed: $($_.Exception.Message). Check AZURE_TENANT_ID, AZURE_CLIENT_ID and AZURE_CLIENT_SECRET in .env."
    }
    return $resp.access_token
}

# A feed URL with credentials (never printed): AZURE_DEVOPS_PAT, else the service principal in .env
# (AZURE_CLIENT_SECRET set), else an Azure DevOps token from az.
function Get-FeedUrl([string]$Url) {
    $token = $env:AZURE_DEVOPS_PAT
    if (-not $token -and $env:AZURE_CLIENT_SECRET) { $token = Get-SpToken }
    if (-not $token) {
        if (-not (Get-Command az -ErrorAction SilentlyContinue)) { throw 'The package feed needs az (az login), AZURE_DEVOPS_PAT, or a service principal in .env' }
        $token = az account get-access-token --resource 499b84ac-1321-427f-aa17-267ca6975798 --query accessToken -o tsv
        if ($LASTEXITCODE -ne 0 -or -not $token) { throw 'Run az login first (or set AZURE_DEVOPS_PAT, or a service principal in .env)' }
    }
    return 'https://build:' + $token + '@' + $Url.Substring('https://'.Length)
}

$port = if ($env:PORT) { $env:PORT } else { '8000' }

if ($Docker) {
    $engine = if (Get-Command docker -ErrorAction SilentlyContinue) { 'docker' }
              elseif (Get-Command podman -ErrorAction SilentlyContinue) { 'podman' }
              else { throw 'Need Docker Desktop or Podman' }
    $buildArgs = @('build', '--build-arg', ('ARTIFACTS_FEED_URL=' + (Get-FeedUrl $SdkFeed)))
    if ($HorizontalFeed) { $buildArgs += @('--build-arg', ('HORIZONTAL_FEED_URL=' + (Get-FeedUrl $HorizontalFeed))) }
    & $engine @buildArgs -t 'ca-agent-proofmesh-sql-check:local' .
    if ($LASTEXITCODE -ne 0) { throw 'The image build failed' }
    Write-Host "Starting on http://localhost:$port (run state kept in volume ca-agent-proofmesh-sql-check-state)"
    & $engine run --rm --env-file .env -e "PORT=$port" -p "${port}:${port}" -v 'ca-agent-proofmesh-sql-check-state:/app/.local' 'ca-agent-proofmesh-sql-check:local'
    exit $LASTEXITCODE
}

$py = $null
foreach ($candidate in 'py -3.13', 'py -3.12', 'py -3.11', 'python', 'python3') {
    $parts = $candidate.Split(' ')
    if (-not (Get-Command $parts[0] -ErrorAction SilentlyContinue)) { continue }
    $pre = @($parts | Select-Object -Skip 1)
    & $parts[0] @pre -c 'import sys; sys.exit(sys.version_info < (3, 11))' 2>$null
    if ($LASTEXITCODE -eq 0) { $py = $parts; break }
}
if (-not $py) { throw 'Need Python 3.11 or later (python.org, or: winget install Python.Python.3.11)' }
$pyPre = @($py | Select-Object -Skip 1)
if (-not (Test-Path .venv)) {
    & $py[0] @pyPre -m venv .venv
    if ($LASTEXITCODE -ne 0) { throw 'Could not create .venv' }
}
$vpy = Join-Path $PSScriptRoot '.venv\Scripts\python.exe'
if (-not (Test-Path $vpy)) { $vpy = Join-Path $PSScriptRoot '.venv/bin/python' }

$want = (Get-FileHash pyproject.toml).Hash
$stamp = Join-Path '.venv' '.installed'
if (-not (Test-Path $stamp) -or (Get-Content $stamp) -ne $want) {
    Write-Host 'Installing packages from the AgentMesh feed...'
    $sdkUrl = if ($env:ARTIFACTS_FEED_URL) { $env:ARTIFACTS_FEED_URL } else { Get-FeedUrl $SdkFeed }
    $index = @('--extra-index-url', $sdkUrl)
    if ($HorizontalFeed) {
        $horizontalUrl = if ($env:HORIZONTAL_FEED_URL) { $env:HORIZONTAL_FEED_URL } else { Get-FeedUrl $HorizontalFeed }
        $index += @('--extra-index-url', $horizontalUrl)
    }
    $env:FEED_CHECK_SDK = $sdkUrl
    $env:FEED_CHECK_HORIZONTAL = if ($HorizontalFeed) { $horizontalUrl } else { '' }
    $feedCheck = @'
import base64, os, sys, urllib.error, urllib.parse, urllib.request

for name in ("SDK", "HORIZONTAL"):
    feed = os.environ.get(f"FEED_CHECK_{name}", "")
    if not feed:
        continue
    u = urllib.parse.urlsplit(feed)
    plain = urllib.parse.urlunsplit((u.scheme, u.hostname + (f":{u.port}" if u.port else ""), u.path, "", ""))
    package = "agentzoo-sdk" if name == "SDK" else "agentzoo-agent-horizontal"
    auth = base64.b64encode(f"build:{urllib.parse.unquote(u.password or '')}".encode()).decode()
    req = urllib.request.Request(plain.rstrip("/") + f"/{package}/", headers={"Authorization": f"Basic {auth}"})
    try:
        urllib.request.urlopen(req, timeout=30).close()
    except urllib.error.HTTPError as exc:
        if exc.code in (401, 403):
            sys.exit(
                f"No read access to the AgentMesh package feed for {package} (HTTP {exc.code}).\n"
                "  Your own account: Ask to be added to the AgentMesh developers group in Azure DevOps (Zenlabs-Agent-Foundry): it gives read access to the package feeds, then run az login again.\n"
                "  A personal access token (AZURE_DEVOPS_PAT): it needs the Packaging: Read scope.\n"
                "  The service principal in .env: it must be a member of the Azure DevOps organisation, with Reader on the feed."
            )
        sys.exit(f"The AgentMesh package feed answered HTTP {exc.code} for {package} ({plain})")
    except Exception as exc:  # noqa: BLE001 - reported
        sys.exit(f"Could not reach the AgentMesh package feed ({plain}): {exc}. Check your internet connection.")
print("Package feed access: ok")

'@
    $feedCheck | & $vpy -
    $feedOk = $LASTEXITCODE
    Remove-Item Env:FEED_CHECK_SDK, Env:FEED_CHECK_HORIZONTAL -ErrorAction SilentlyContinue
    if ($feedOk -ne 0) { exit $feedOk }
    & $vpy -m pip install -q --upgrade pip
    & $vpy -m pip install -q @index -e '.[dev]'
    if ($LASTEXITCODE -ne 0) { throw 'pip install failed: see the error above (the feed answered, so check the package versions and your network)' }
    Set-Content -Path $stamp -Value $want
}

# Governance (PII) needs spaCy's en_core_web_lg; without it the first run downloads it mid-request.
# SPACY_MODEL_WHEEL: a local or mirrored copy of the model wheel, instead of downloading it.
& $vpy -c 'import en_core_web_lg' 2>$null
if ($LASTEXITCODE -ne 0) {
    Write-Host 'Installing the spaCy model en_core_web_lg (about 400 MB, once)...'
    if ($env:SPACY_MODEL_WHEEL) { & $vpy -m pip install -q $env:SPACY_MODEL_WHEEL } else { & $vpy -m spacy download en_core_web_lg }
    if ($LASTEXITCODE -ne 0) { throw 'Could not install en_core_web_lg' }
}

$probe = @'
import concurrent.futures, os, sys, urllib.request

keys = sorted(k for k, v in os.environ.items() if k.startswith("MCP_") and k.endswith("_URL") and v)
print("Checking the platform endpoints (a first call can take a minute: they scale to zero)...")

def probe(key):
    try:
        with urllib.request.urlopen(os.environ[key].rstrip("/") + "/health", timeout=90):
            return key, ""
    except Exception as exc:  # noqa: BLE001 - reported below
        return key, str(exc)[:160]

bad = []
with concurrent.futures.ThreadPoolExecutor(8) as pool:
    for key, error in pool.map(probe, keys):
        print(f"  {key}: {'ok' if not error else 'NOT REACHABLE: ' + error}")
        if error:
            bad.append(key)
if bad:
    sys.exit("Not reachable: " + ", ".join(bad) + ". Is the VPN up, and are the URLs in .env right?")
'@
$probe | & $vpy -
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }

if (-not $env:AZURE_CLIENT_SECRET -and (Get-Command az -ErrorAction SilentlyContinue)) {
    az account show *> $null
    if ($LASTEXITCODE -ne 0) { Write-Host 'Note: no Azure identity (az login, or a service principal in .env). Content safety checks will fail, and strict agents refuse to run.' }
}

if ($env:AZURE_TENANT_ID -and $env:AUTH_MODE -ne 'dev') {
    Write-Host 'Note: AZURE_TENANT_ID is set but AUTH_MODE is not dev: MCP calls will carry Entra tokens, which the platform''s MCP servers refuse unless that identity is registered with them, and /invoke will want a token. Set AUTH_MODE=dev in .env.'
}

if (-not $env:AGENT_NAME_PREFIX) {
    Write-Host 'Note: AGENT_NAME_PREFIX is empty: everyone running proofmesh-sql-check unprefixed shares its budgets and audit. Set your team id in .env.'
}
Write-Host "Starting on http://localhost:$port  (POST /invoke/proofmesh-sql-check, GET /intake, GET /health)"
& $vpy -m proofmesh_sql_check.app
exit $LASTEXITCODE
