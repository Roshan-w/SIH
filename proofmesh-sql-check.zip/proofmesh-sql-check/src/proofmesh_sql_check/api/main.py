"""The FastAPI app: lifespan, middleware, routers."""

from __future__ import annotations

import os
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager

from fastapi import FastAPI

from agentzoo.serving.end_user import EndUserMiddleware

from ..config import AGENT_NAME, DEFINITIONS_DIR
from ..observability import maybe_setup_tracing
from ..runtime import definition_runtime, load_agent, registry, triggers
from .routers import files, health, intake, invoke


@asynccontextmanager
async def lifespan(application: FastAPI) -> AsyncIterator[None]:
    # Tracing only when a collector is configured: the SDK's default is an in-environment host,
    # which a laptop cannot reach (every export would fail and retry in the background).
    maybe_setup_tracing(AGENT_NAME)
    registry.register(load_agent())
    triggers.load_definitions_dir(DEFINITIONS_DIR)
    await registry.register_with_gateway()
    async with triggers.lifespan():
        yield
    # No deregistration on shutdown: one replica scaling in must not take the agent out of
    # routing. The heartbeat stops and the gateway marks the agent stale.


app = FastAPI(
    title='Proofmesh Sql Check',
    version='1.0.0',
    description='Explains a SQL change, reads its proof from the Diamond engine, and sends it to a person for approval. Never marks a change safe on its own.',
    lifespan=registry.scoped_lifespan(lifespan),
)
# X-User-* from the gateway -> end-user context, so knowledge retrieval is permission-aware.
app.add_middleware(EndUserMiddleware)
app.state.definition_runtime = definition_runtime
app.state.trigger_host = triggers
app.include_router(definition_runtime.router())
app.include_router(triggers.router())
app.include_router(health.router)
app.include_router(invoke.router)
app.include_router(intake.router)
app.include_router(files.router)


def main() -> None:
    """``python -m proofmesh_sql_check.app``: serve on $HOST:$PORT (from .env), one worker (paused runs and
    decisions are coordinated through the run stores)."""
    import uvicorn

    uvicorn.run(app, host=os.environ.get("HOST", "127.0.0.1"), port=int(os.environ.get("PORT") or 8000))
