"""Env loading, agent naming/prefixing, build provenance.

Imported first (directly or transitively) by everything else in this package: this is where
``.env`` is read and ``AGENTMESH_INTEGRITY_MODE`` gets its default, before any SDK call needs them.
"""

from __future__ import annotations

import os
import re
from pathlib import Path

import yaml
from dotenv import dotenv_values

# <project>/.env, before anything reads the environment. A variable already set (non-empty) wins,
# so a container's settings (docker --env-file, Container App env) are never overridden by a stray file.
PROJECT_DIR = Path(__file__).resolve().parent.parent.parent
for _key, _value in dotenv_values(PROJECT_DIR / ".env").items():
    if _value is not None and not os.environ.get(_key):
        os.environ[_key] = _value
# Live unless asked otherwise: in a dev / local environment the SDK would default to simulate.
os.environ.setdefault("AGENTMESH_INTEGRITY_MODE", "live")

#: The agent's name in the Builder. Requests may use it even when AGENT_NAME_PREFIX renames the agent.
BASE_NAME = 'proofmesh-sql-check'

# The container sets AGENT_DEFINITIONS_DIR=/app/definitions; source runs use <project>/definitions
# (a relative value, as in .env.example, is taken from the project directory).
DEFINITIONS_DIR = PROJECT_DIR / os.environ.get("AGENT_DEFINITIONS_DIR", "definitions")


def _prefixed(prefix: str, source: Path) -> tuple[str, Path]:
    """Serve the definition as ``<prefix>-<name>`` (triggers too) from a copy under ./.local.

    Budgets, rate limits, audit and approvals are keyed by the agent name, and trigger locks by the
    trigger name, so many people running the same downloaded agent against one platform would
    share them. A prefix per person or team (AGENT_NAME_PREFIX, say team-07) keeps them apart.
    """
    if not re.fullmatch(r"[a-z0-9][a-z0-9-]{0,30}", prefix):
        raise RuntimeError(f"AGENT_NAME_PREFIX={prefix!r}: use lowercase letters, digits and '-', at most 31")
    target = Path.cwd() / ".local" / "definitions"
    target.mkdir(parents=True, exist_ok=True)
    for stale in target.glob("*.y*ml"):
        stale.unlink()
    for file in sorted(source.glob("*.y*ml")):
        data = yaml.safe_load(file.read_text(encoding="utf-8")) or {}
        meta = data.setdefault("metadata", {})
        meta["name"] = f"{prefix}-{meta.get('name') or file.stem}"
        for trigger in data.get("triggers") or []:
            if isinstance(trigger, dict) and trigger.get("name"):
                trigger["name"] = f"{prefix}-{trigger['name']}"
        (target / f"{meta['name']}.yaml").write_text(yaml.safe_dump(data, sort_keys=False), encoding="utf-8")
    return f"{prefix}-{BASE_NAME}", target


_PREFIX = os.environ.get("AGENT_NAME_PREFIX", "").strip().lower()
AGENT_NAME, DEFINITIONS_DIR = _prefixed(_PREFIX, DEFINITIONS_DIR) if _PREFIX else (BASE_NAME, DEFINITIONS_DIR)

# Build provenance, read once at import (never per request): GET /health -> "build".
BUILD = {
    "commit": os.environ.get("GIT_COMMIT", "unknown"),
    "build_number": os.environ.get("BUILD_NUMBER", "unknown"),
}
