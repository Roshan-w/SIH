"""The definition loads and compiles with the SDK this host runs on."""

from __future__ import annotations

from proofmesh_onboarder import app as host


def test_the_host_loads_its_one_agent() -> None:
    agent = host.load_agent()
    assert agent.manifest.name == host.AGENT_NAME
